package eu.raidersheaven.RHTintHealth.Main;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

public class TabComplete implements TabCompleter {
	public List<String> onTabComplete(final CommandSender sender, final Command cmd, final String s,
			final String[] args) {

		final List<String> l = new ArrayList<String>();

		if (args.length == 1) {

			l.add("toggle");

			if (sender.hasPermission("RHTintHealth.reload") || sender.hasPermission("RHTintHealth.*")) {

				l.add("reload");

			}

		}

		return l;
	}
}
