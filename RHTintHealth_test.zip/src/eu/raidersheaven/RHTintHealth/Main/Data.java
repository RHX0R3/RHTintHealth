package eu.raidersheaven.RHTintHealth.Main;

import lombok.Getter;

public class Data {

	@Getter
	private static String prefix = "�8[�c�lRHTintHealth�8] ";

	@Getter
	// private static String noPerm = prefix + "&7Dazu hast du &ckeinen &7Zugriff.";
	private static String noPerm = prefix + "�7You do �cnot �7have the needed permission.";

	public static String getPrefix() {
		return prefix;
	}

	public static String getNoPerm() {
		return noPerm;
	}

}
