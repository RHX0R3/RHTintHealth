package eu.raidersheaven.RHTintHealth.Forked;

import org.bukkit.entity.Player;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.CommandExecutor;

public class TintHealth_Command implements CommandExecutor {
	Main plugin;
	final String heart = "\u2764 ";

	public TintHealth_Command(final Main plugin) {
		this.plugin = plugin;
	}

	@SuppressWarnings("unused")
	public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {

		if (args.length == 1) {

			if (args[0].equalsIgnoreCase("reload")) {

				if (sender.hasPermission("RHTintHealth.reload") || sender.hasPermission("RHTintHealth.*")) {

					this.plugin.reloadConfig();
//					this.plugin.loadConfig();

					sender.sendMessage(
							ChatColor.translateAlternateColorCodes('&', this.plugin.getConfig().getString("chat-prefix")
									+ this.plugin.getConfig().getString("reload-msg")));

				} else {

					sender.sendMessage(
							ChatColor.translateAlternateColorCodes('&', this.plugin.getConfig().getString("chat-prefix")
									+ this.plugin.getConfig().getString("no-permission-msg")));

				}

			} else if (args[0].equalsIgnoreCase("toggle")) {

				if (sender instanceof Player) {

					final String prefix = ChatColor.DARK_RED + "\u2764 " + ChatColor.RED;
					final Player p = (Player) sender;

					if (p.hasPermission("RHTintHealth.toggle") || p.hasPermission("RHTintHealth.*")) {

						this.plugin.functions.togglePlayerTint(p);
						if (this.plugin.functions.isTintEnabled(p)) {

							p.sendMessage(ChatColor.translateAlternateColorCodes('&',
									this.plugin.getConfig().getString("chat-prefix")
											+ this.plugin.getConfig().getString("tint-enabled-msg")));
						} else {

							p.sendMessage(ChatColor.translateAlternateColorCodes('&',
									this.plugin.getConfig().getString("chat-prefix")
											+ this.plugin.getConfig().getString("tint-disabled-msg")));
						}

					} else {

						p.sendMessage(ChatColor.translateAlternateColorCodes('&',
								this.plugin.getConfig().getString("chat-prefix")
										+ this.plugin.getConfig().getString("no-permission-msg")));
						p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BIT, 1.0f, 0.6f);
						p.playSound(p.getLocation(), Sound.BLOCK_LAVA_POP, 3.0f, 1.0f);
						p.playSound(p.getLocation(), Sound.ENTITY_ITEM_FRAME_REMOVE_ITEM, 3.0f, 0.3f);
					}

				} else {

					sender.sendMessage(
							ChatColor.translateAlternateColorCodes('&', this.plugin.getConfig().getString("chat-prefix")
									+ this.plugin.getConfig().getString("ingame-only-msg")));

				}

			} else {

				this.sendHelpMessage(sender);
			}

		} else {

			this.sendHelpMessage(sender);

		}

		return true;

	}

	@SuppressWarnings("unused")
	public void sendHelpMessage(final CommandSender sender) {

		String prefix = this.plugin.getConfig().getString("chat-prefix");

		if (sender instanceof Player) {

			prefix = ChatColor.DARK_RED + "\u2764 " + ChatColor.GRAY;

		}

		//sender.sendMessage(this.plugin.getConfig().getString(""));
		
		for (String message : this.plugin.getConfig().getStringList("tinthealth-usage-msg")) {

			sender.sendMessage(ChatColor.translateAlternateColorCodes('&', message));
		}
	}
}
