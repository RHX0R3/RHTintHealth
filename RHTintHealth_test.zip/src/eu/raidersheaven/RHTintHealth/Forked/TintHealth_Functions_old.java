package eu.raidersheaven.RHTintHealth.Forked;

import org.bukkit.entity.Damageable;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import org.bukkit.Bukkit;
import java.util.List;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class TintHealth_Functions_old {
	private static Method handle;
	private static Method sendPacket;
	private static Method center;
	private static Method distance;
	private static Method time;
	private static Method movement;
	private static Field player_connection;
	private static Constructor<?> constructor;
	private static Constructor<?> border_constructor;
	private static Object constant;
	Main plugin;
	protected List<String> togglelist;

	@SuppressWarnings("unused")
	private static boolean inClass(final Method[] methods, final String methodName) {
		for (final Method m : methods) {
			if (m.getName() == methodName) {
				return true;
			}
		}
		return false;
	}

	private static Class<?> getClass(final String prefix, final String name) throws Exception {
		return Class
				.forName(prefix + "."
						+ Bukkit.getServer().getClass().getPackage().getName()
								.substring(Bukkit.getServer().getClass().getPackage().getName().lastIndexOf(".") + 1)
						+ "." + name);
	}

	protected TintHealth_Functions_old(final Main plugin) {
		this.togglelist = new ArrayList<String>();
		this.plugin = plugin;
	}

	protected void sendBorder(final Player p, int percentage) {
		percentage = Math.round((float) (percentage / this.plugin.intensity));
		this.setBorder(p, percentage);
		if (this.plugin.fade && (p.hasPermission("RHTintHealth.fade") || p.hasPermission("RHTintHealth.*"))) {
			this.fadeBorder(p, percentage, this.plugin.fadetime);
		}
	}

	protected void fadeBorder(final Player p, final int percentage, final long time) {
		final int dist = -10000 * percentage + 1300000;
		this.sendWorldBorderPacket(p, 0, 200000.0, dist, 1000L * time + 4000L);
		this.plugin.debug("Sent fade border for player " + p.getName());
	}

	protected void removeBorder(final Player p) {
		this.sendWorldBorderPacket(p, 0, 200000.0, 200000.0, 0L);
		this.plugin.debug("Removed tint for player " + p.getName());
	}

	protected void setBorder(final Player p, final int percentage) {
		final int dist = -10000 * percentage + 1300000;
		this.sendWorldBorderPacket(p, dist, 200000.0, 200000.0, 0L);
		this.plugin.debug("Set " + percentage + "% tint for player " + p.getName());
	}

	protected void sendWorldBorderPacket(final Player p, final int dist, final double oldradius, final double newradius,
			final long delay) {
		try {
			final Object wb = TintHealth_Functions_old.border_constructor.newInstance(new Object[0]);
			final Method worldServer = getClass("org.bukkit.craftbukkit", "CraftWorld").getMethod("getHandle",
					(Class<?>[]) new Class[0]);
			final Field world = getClass("net.minecraft.server", "WorldBorder").getField("world");
			world.set(wb, worldServer.invoke(p.getWorld(), new Object[0]));
			TintHealth_Functions_old.center.invoke(wb, p.getLocation().getX(), p.getLocation().getY());
			TintHealth_Functions_old.distance.invoke(wb, dist);
			TintHealth_Functions_old.time.invoke(wb, 15);
			TintHealth_Functions_old.movement.invoke(wb, oldradius, newradius, delay);
			final Object packet = TintHealth_Functions_old.constructor.newInstance(wb, TintHealth_Functions_old.constant);
			TintHealth_Functions_old.sendPacket.invoke(
					TintHealth_Functions_old.player_connection.get(TintHealth_Functions_old.handle.invoke(p, new Object[0])),
					packet);
		} catch (Exception x) {
			x.printStackTrace();
		}
	}

	protected int getPlayerHealth(final Player p) {
		return (int) ((Damageable) p).getHealth();
	}

	@SuppressWarnings("deprecation")
	protected int getMaxPlayerHealth(final Player p) {
		return (int) ((Damageable) p).getMaxHealth();
	}

	@SuppressWarnings("deprecation")
	protected int getPlayerMissingHearts(final Player p) {
		return (int) ((Damageable) p).getMaxHealth();
	}

	protected int getPlayerHealthPercentage(final Player p) {
		final int health = this.getPlayerHealth(p);
		final int maxhealth = this.getMaxPlayerHealth(p);
		return Math.round((float) (health * 100 / maxhealth));
	}

	protected void disablePlayerTint(final Player p) {
		this.togglelist.add(p.getName());
	}

	protected void enablePlayerTint(final Player p) {
		final String pname = p.getName();
		if (this.togglelist.contains(pname)) {
			this.togglelist.remove(pname);
		}
	}

	protected void togglePlayerTint(final Player p) {
		if (this.isTintEnabled(p)) {
			this.disablePlayerTint(p);
		} else {
			this.enablePlayerTint(p);
		}
	}

	protected boolean isTintEnabled(final Player p) {
		return !this.togglelist.contains(p.getName());
	}

	static {
		try {
			TintHealth_Functions_old.handle = getClass("org.bukkit.craftbukkit", "entity.CraftPlayer")
					.getMethod("getHandle", (Class<?>[]) new Class[0]);
			TintHealth_Functions_old.player_connection = getClass("net.minecraft.server", "EntityPlayer")
					.getField("playerConnection");
			for (final Method m : getClass("net.minecraft.server", "PlayerConnection").getMethods()) {
				if (m.getName().equals("sendPacket")) {
					TintHealth_Functions_old.sendPacket = m;
					break;
				}
			}
			Class<?> enumclass;
			try {
				enumclass = getClass("net.minecraft.server", "EnumWorldBorderAction");
			} catch (ClassNotFoundException x) {
				enumclass = getClass("net.minecraft.server", "PacketPlayOutWorldBorder$EnumWorldBorderAction");
			}
			TintHealth_Functions_old.constructor = getClass("net.minecraft.server", "PacketPlayOutWorldBorder")
					.getConstructor(getClass("net.minecraft.server", "WorldBorder"), enumclass);
			TintHealth_Functions_old.border_constructor = getClass("net.minecraft.server", "WorldBorder")
					.getConstructor((Class<?>[]) new Class[0]);
			final String setCenter = "setCenter";
			final String setWarningDistance = "setWarningDistance";
			final String setWarningTime = "setWarningTime";
			final String transitionSizeBetween = "transitionSizeBetween";
			TintHealth_Functions_old.center = getClass("net.minecraft.server", "WorldBorder").getMethod(setCenter,
					Double.TYPE, Double.TYPE);
			TintHealth_Functions_old.distance = getClass("net.minecraft.server", "WorldBorder")
					.getMethod(setWarningDistance, Integer.TYPE);
			TintHealth_Functions_old.time = getClass("net.minecraft.server", "WorldBorder").getMethod(setWarningTime,
					Integer.TYPE);
			TintHealth_Functions_old.movement = getClass("net.minecraft.server", "WorldBorder")
					.getMethod(transitionSizeBetween, Double.TYPE, Double.TYPE, Long.TYPE);
			for (final Object o : enumclass.getEnumConstants()) {
				if (o.toString().equals("INITIALIZE")) {
					TintHealth_Functions_old.constant = o;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
