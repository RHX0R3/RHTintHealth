package eu.raidersheaven.RHTintHealth.Forked;

import org.bukkit.entity.Damageable;
import org.bukkit.entity.Player;
import net.minecraft.network.protocol.game.ClientboundInitializeBorderPacket;
import net.minecraft.world.level.border.WorldBorder;

import java.util.ArrayList;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_17_R1.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_17_R1.CraftWorld;

import java.util.List;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class TintHealth_Functions {

	private static Method handle;
	private static Method sendPacket;
	private static Method center;
	private static Method distance;
	private static Method time;
	private static Method movement;
	private static Field player_connection;
	private static Constructor<?> constructor;
	private static Constructor<?> border_constructor;
	private static Object constant;
	Main plugin;
	protected List<String> togglelist;

	public static String version = Bukkit.getServer().getClass().getPackage().getName();
	{
		// net.minecraft.server.1_16_R1 -> 1_16_R1
		version = version.substring(version.lastIndexOf('.'));
	}

	@SuppressWarnings("unused")
	private static boolean inClass(final Method[] methods, final String methodName) {
		for (final Method m : methods) {
			if (m.getName() == methodName) {
				return true;
			}
		}
		return false;
	}

	private static Class<?> getClass(final String prefix, final String name) throws Exception {
		return Class
				.forName(prefix + "."
						+ Bukkit.getServer().getClass().getPackage().getName()
								.substring(Bukkit.getServer().getClass().getPackage().getName().lastIndexOf(".") + 1)
						+ "." + name);
	}

	protected TintHealth_Functions(final Main plugin) {
		this.togglelist = new ArrayList<String>();
		this.plugin = plugin;
	}

	protected void sendBorder(final Player p, int percentage) {
		percentage = Math.round((float) (percentage / this.plugin.intensity));
		this.setBorder(p, percentage);
		if (this.plugin.fade && (p.hasPermission("RHTintHealth.fade") || p.hasPermission("RHTintHealth.*"))) {
			this.fadeBorder(p, percentage, this.plugin.fadetime);
		}
	}

	protected void fadeBorder(final Player p, final int percentage, final long time) {
		final int dist = -10000 * percentage + 1300000;
		this.sendWorldBorderPacket(p, 0, 200000.0, dist, 1000L * time + 4000L);
		this.plugin.debug("Sent fade border for player " + p.getName());
	}

	protected void removeBorder(final Player p) {
		this.sendWorldBorderPacket(p, 0, 200000.0, 200000.0, 0L);
		this.plugin.debug("Removed tint for player " + p.getName());
	}

	protected void setBorder(final Player p, final int percentage) {
		final int dist = -10000 * percentage + 1300000;
		this.sendWorldBorderPacket(p, dist, 200000.0, 200000.0, 0L);
		this.plugin.debug("Set " + percentage + "% tint for player " + p.getName());
	}

	protected void sendWorldBorderPacket(final Player p, final int dist, final double oldradius, final double newradius,
			final long delay) {

		//
		// 1.17 shit
		//

		if (version.equals(".v1_17_R1")) {

			try {
				final Object wb = TintHealth_Functions.border_constructor.newInstance(new Object[0]);
				final Method worldServer = getClass("org.bukkit.craftbukkit.v1_17_R1", "CraftWorld")
						.getMethod("getHandle", (Class<?>[]) new Class[0]);
				final Field world = getClass("net.minecraft.world.level.border", "WorldBorder").getField("world");

				world.set(wb, worldServer.invoke(p.getWorld(), new Object[0]));

				TintHealth_Functions.center.invoke(wb, p.getLocation().getX(), p.getLocation().getY());
				TintHealth_Functions.distance.invoke(wb, dist);
				TintHealth_Functions.time.invoke(wb, 15);
				TintHealth_Functions.movement.invoke(wb, oldradius, newradius, delay);

				final Object packet = TintHealth_Functions.constructor.newInstance(wb, TintHealth_Functions.constant);

				TintHealth_Functions.sendPacket.invoke(TintHealth_Functions.player_connection
						.get(TintHealth_Functions.handle.invoke(p, new Object[0])), packet);

			} catch (Exception x) {
				x.printStackTrace();
			}

		} else if (Bukkit.getVersion().contains("1.16")) {

			try {
				final Object wb = TintHealth_Functions.border_constructor.newInstance(new Object[0]);
				final Method worldServer = getClass("org.bukkit.craftbukkit", "CraftWorld").getMethod("getHandle",
						(Class<?>[]) new Class[0]);
				final Field world = getClass("net.minecraft.server", "WorldBorder").getField("world");
				world.set(wb, worldServer.invoke(p.getWorld(), new Object[0]));
				TintHealth_Functions.center.invoke(wb, p.getLocation().getX(), p.getLocation().getY());
				TintHealth_Functions.distance.invoke(wb, dist);
				TintHealth_Functions.time.invoke(wb, 15);
				TintHealth_Functions.movement.invoke(wb, oldradius, newradius, delay);
				final Object packet = TintHealth_Functions.constructor.newInstance(wb, TintHealth_Functions.constant);
				TintHealth_Functions.sendPacket.invoke(TintHealth_Functions.player_connection
						.get(TintHealth_Functions.handle.invoke(p, new Object[0])), packet);

			} catch (Exception x) {
				x.printStackTrace();
			}

		}
	}

	// /*
	// externes Snippet / geh�rt nicht zum Plugin
	//

	public void sendWorldBorder(Player player, Color color, double size, Location centerLocation) {
		WorldBorder worldBorder = new WorldBorder();
		worldBorder.world = ((CraftWorld) centerLocation.getWorld()).getHandle();
		worldBorder.setCenter(centerLocation.getBlockX() + 0.5, centerLocation.getBlockZ() + 0.5);

		if (color == Color.WHITE) {
			worldBorder.setSize(Integer.MAX_VALUE);
		} else {
			worldBorder.setSize(size);
		}

		worldBorder.setWarningDistance(0);
		worldBorder.setWarningTime(0);

		if (color == Color.RED) {
			worldBorder.transitionSizeBetween(size, size - 1.0D, 20000000L);
		} else if (color == Color.GREEN) {
			worldBorder.transitionSizeBetween(size - 0.1D, size, 20000000L);
		}

		((CraftPlayer) player).getHandle().b.sendPacket(new ClientboundInitializeBorderPacket(worldBorder));
	}

	// */

	protected int getPlayerHealth(final Player p) {
		return (int) ((Damageable) p).getHealth();
	}

	@SuppressWarnings("deprecation")
	protected int getMaxPlayerHealth(final Player p) {
		return (int) ((Damageable) p).getMaxHealth();
	}

	@SuppressWarnings("deprecation")
	protected int getPlayerMissingHearts(final Player p) {
		return (int) ((Damageable) p).getMaxHealth();
	}

	protected int getPlayerHealthPercentage(final Player p) {
		final int health = this.getPlayerHealth(p);
		final int maxhealth = this.getMaxPlayerHealth(p);
		return Math.round((float) (health * 100 / maxhealth));
	}

	protected void disablePlayerTint(final Player p) {
		this.togglelist.add(p.getName());
	}

	protected void enablePlayerTint(final Player p) {
		final String pname = p.getName();
		if (this.togglelist.contains(pname)) {
			this.togglelist.remove(pname);
		}
	}

	protected void togglePlayerTint(final Player p) {
		if (this.isTintEnabled(p)) {
			this.disablePlayerTint(p);
		} else {
			this.enablePlayerTint(p);
		}
	}

	protected boolean isTintEnabled(final Player p) {
		return !this.togglelist.contains(p.getName());
	}

	static {

		// /*
		// 1.17 shit
		//

		if (version.equals(".v1_17_R1")) {

			try {
				TintHealth_Functions.handle = getClass("org.bukkit.craftbukkit.v1_17_R1", "entity.CraftPlayer")
						.getMethod("getHandle", (Class<?>[]) new Class[0]);
				TintHealth_Functions.player_connection = getClass("net.minecraft.server.level", "EntityPlayer")
						.getField("playerConnection");
				for (final Method m : getClass("net.minecraft.server.network", "PlayerConnection").getMethods()) {
					if (m.getName().equals("sendPacket")) {
						TintHealth_Functions.sendPacket = m;
						break;
					}
				}
				Class<?> enumclass;
				try {
					enumclass = getClass("net.minecraft.server", "EnumWorldBorderAction");
				} catch (ClassNotFoundException x) {
					enumclass = getClass("net.minecraft.network.protocol.game",
							"ClientboundInitializeBorderPacket($EnumWorldBorderAction");
				}
				TintHealth_Functions.constructor = getClass("net.minecraft.network.protocol.game",
						"ClientboundInitializeBorderPacket(")
								.getConstructor(getClass("net.minecraft.world.level.border", "WorldBorder"), enumclass);
				TintHealth_Functions.border_constructor = getClass("net.minecraft.world.level.border", "WorldBorder")
						.getConstructor((Class<?>[]) new Class[0]);
				final String setCenter = "setCenter";
				final String setWarningDistance = "setWarningDistance";
				final String setWarningTime = "setWarningTime";
				final String transitionSizeBetween = "transitionSizeBetween";
				TintHealth_Functions.center = getClass("net.minecraft.world.level.border", "WorldBorder")
						.getMethod(setCenter, Double.TYPE, Double.TYPE);
				TintHealth_Functions.distance = getClass("net.minecraft.world.level.border", "WorldBorder")
						.getMethod(setWarningDistance, Integer.TYPE);
				TintHealth_Functions.time = getClass("net.minecraft.world.level.border", "WorldBorder")
						.getMethod(setWarningTime, Integer.TYPE);
				TintHealth_Functions.movement = getClass("net.minecraft.world.level.border", "WorldBorder")
						.getMethod(transitionSizeBetween, Double.TYPE, Double.TYPE, Long.TYPE);
				for (final Object o : enumclass.getEnumConstants()) {
					if (o.toString().equals("INITIALIZE")) {
						TintHealth_Functions.constant = o;
						break;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			// */

		} else if (Bukkit.getVersion().contains("1.16")) {

			try {
				TintHealth_Functions.handle = getClass("org.bukkit.craftbukkit", "entity.CraftPlayer")
						.getMethod("getHandle", (Class<?>[]) new Class[0]);
				TintHealth_Functions.player_connection = getClass("net.minecraft.server", "EntityPlayer")
						.getField("playerConnection");
				for (final Method m : getClass("net.minecraft.server", "PlayerConnection").getMethods()) {
					if (m.getName().equals("sendPacket")) {
						TintHealth_Functions.sendPacket = m;
						break;
					}
				}
				Class<?> enumclass;
				try {
					enumclass = getClass("net.minecraft.server", "EnumWorldBorderAction");
				} catch (ClassNotFoundException x) {
					enumclass = getClass("net.minecraft.server", "PacketPlayOutWorldBorder$EnumWorldBorderAction");
				}
				TintHealth_Functions.constructor = getClass("net.minecraft.server", "PacketPlayOutWorldBorder")
						.getConstructor(getClass("net.minecraft.server", "WorldBorder"), enumclass);
				TintHealth_Functions.border_constructor = getClass("net.minecraft.server", "WorldBorder")
						.getConstructor((Class<?>[]) new Class[0]);
				final String setCenter = "setCenter";
				final String setWarningDistance = "setWarningDistance";
				final String setWarningTime = "setWarningTime";
				final String transitionSizeBetween = "transitionSizeBetween";
				TintHealth_Functions.center = getClass("net.minecraft.server", "WorldBorder").getMethod(setCenter,
						Double.TYPE, Double.TYPE);
				TintHealth_Functions.distance = getClass("net.minecraft.server", "WorldBorder")
						.getMethod(setWarningDistance, Integer.TYPE);
				TintHealth_Functions.time = getClass("net.minecraft.server", "WorldBorder").getMethod(setWarningTime,
						Integer.TYPE);
				TintHealth_Functions.movement = getClass("net.minecraft.server", "WorldBorder")
						.getMethod(transitionSizeBetween, Double.TYPE, Double.TYPE, Long.TYPE);
				for (final Object o : enumclass.getEnumConstants()) {
					if (o.toString().equals("INITIALIZE")) {
						TintHealth_Functions.constant = o;
						break;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}
}
