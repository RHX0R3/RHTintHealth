package eu.raidersheaven.RHTintHealth.Forked;

import java.util.List;
import java.util.ArrayList;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import org.bukkit.configuration.file.FileConfiguration;
import java.io.IOException;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.TabCompleter;
import org.bukkit.plugin.java.JavaPlugin;

import eu.raidersheaven.RHTintHealth.Main.Data;
import eu.raidersheaven.RHTintHealth.Main.TabComplete;
import eu.raidersheaven.metrics.Metrics;

public final class Main extends JavaPlugin {
	private static Main plugin;
	public TintHealth_Functions functions;
	public boolean fade;
	protected int fadetime;
	protected int intensity;
	protected int minhearts;
	protected boolean damagemode;
	protected boolean enabled;
	protected boolean debug;

	public static String Version = "1.2.0-1.17_R1";
	public static String shortVersion = "1.17_R1";

	public Main() {
		this.fade = false;
		this.fadetime = 5;
		this.intensity = 1;
		this.minhearts = -1;
		this.damagemode = false;
		this.enabled = true;
		this.debug = false;
	}

	public static Main getInstance() {
		return Main.plugin;
	}

	@SuppressWarnings("unused")
	public void onEnable() {

		this.getConfig().options().copyDefaults();
		this.saveDefaultConfig();

		final FileConfiguration config = this.getConfig();

		this.loadConfig();
		this.loadPlayerToggles();

		this.functions = new TintHealth_Functions(this);

		if (this.enabled) {
			new TintHealth_PlayerListener(this);
		}

		this.getCommand("tinthealth").setTabCompleter((TabCompleter) new TabComplete());

		this.getCommand("tinthealth").setExecutor((CommandExecutor) new TintHealth_Command(this));

		// Metrics (bstats)
		// All you have to do is adding the following two lines in your onEnable method.
		// You can find the plugin ids of your plugins on the page
		// https://bstats.org/what-is-my-plugin-id
		int pluginId = 11573; // <-- Replace with the id of your plugin!
		Metrics metrics = new Metrics(this, pluginId);

		Bukkit.getConsoleSender().sendMessage(String.valueOf(Data.getPrefix()) + "§7The plugin has been §a§lloaded§7!");
		Bukkit.getConsoleSender().sendMessage(String.valueOf(Data.getPrefix()) + "§7You are using version §d§l"
				+ Main.shortVersion + " §7w/ §c§l💕§7 by §f§lX0R3");
		Bukkit.getConsoleSender().sendMessage(String.valueOf(Data.getPrefix()) + "§8Info:");
		Bukkit.getConsoleSender().sendMessage(String.valueOf(Data.getPrefix())
				+ "§8If you want your server be presented on the plugin page, then please contact me! :)");

	}

	public void loadConfig() {

		final FileConfiguration config = this.getConfig();

		// Plugin ist aktiviert
		this.enabled = config.getBoolean("tint-enabled");

		// Fade ist aktiviert
		this.fade = config.getBoolean("fade-enabled");

		// Fade Timer
		this.fadetime = config.getInt("fade-time");

		// Intensität
		this.intensity = config.getInt("intensity-modifier");

		// Damage-Modues ist aktiviert
		this.damagemode = config.getBoolean("damage-mode-enabled");

		// Minimale Lebenspunkte
		this.minhearts = config.getInt("minimum-health");

		// Debug-Modus ist aktiviert
		this.debug = config.getBoolean("debug-enabled");

		if (this.minhearts < 0) {

			this.minhearts = 100000;
		}

		Bukkit.getConsoleSender().sendMessage(String.valueOf(Data.getPrefix()) + "Configuration successfully loaded");

	}

	public void debug(final String message) {

		if (this.debug) {

			Bukkit.getConsoleSender()
					.sendMessage(String.valueOf(Data.getPrefix()) + "§c" + "[DEBUG] " + "§r" + message);

		}

	}

	private void loadPlayerToggles() {

		final File f = new File("plugins/RHTintHealth", "disabled-players.yml");
		final YamlConfiguration fc = YamlConfiguration.loadConfiguration(f);

		fc.options().copyDefaults(true);
		fc.addDefault("players", (Object) null);

		if (fc.getStringList("players") != null) {

			for (final String pname : fc.getStringList("players")) {

				this.functions.togglelist.add(pname);

			}

		}

		try {

			fc.save(f);

		} catch (IOException e) {

			e.printStackTrace();

		}

		Bukkit.getConsoleSender().sendMessage(String.valueOf(Data.getPrefix()) + "§r"
				+ fc.getStringList("players").size() + "§a" + " player toggles loaded");

	}

	private void savePlayerToggles() {

		final File f = new File("plugins/RHTintHealth", "disabled-players.yml");
		final YamlConfiguration fc = YamlConfiguration.loadConfiguration(f);
		final List<String> list = new ArrayList<String>();

		for (final String pname : this.functions.togglelist) {

			list.add(pname);

		}

		fc.set("players", (Object) list);

		try {

			fc.save(f);

		} catch (IOException e) {

			e.printStackTrace();

		}

		Bukkit.getConsoleSender()
				.sendMessage(String.valueOf(Data.getPrefix()) + "§r" + list.size() + "§a" + " player toggles saved");

	}

	public void onDisable() {

		this.savePlayerToggles();

		Bukkit.getConsoleSender()
				.sendMessage(String.valueOf(Data.getPrefix()) + "§7The plugin has been §c§lunloaded§7!");
	}

}
