package eu.raidersheaven.RHTintHealth.Forked;

import org.bukkit.entity.Damageable;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.Bukkit;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.EventPriority;
import org.bukkit.event.EventHandler;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.event.Listener;

public class TintHealth_PlayerListener implements Listener {
	Main plugin;

	protected TintHealth_PlayerListener(final Main plugin) {
		this.plugin = plugin;
		plugin.getServer().getPluginManager().registerEvents((Listener) this, (Plugin) plugin);
	}

	protected boolean isEnabled() {
		return this.plugin.enabled;
	}

	@EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
	protected void onDamage(final EntityDamageEvent e) {
		if (this.isEnabled() && e.getEntity() instanceof Player) {
			final Player p = (Player) e.getEntity();
			if (this.plugin.functions.isTintEnabled(p)) {
				int health = this.plugin.functions.getPlayerHealth(p);
				if (health <= this.plugin.minhearts) {
					final int maxhealth = this.plugin.functions.getMaxPlayerHealth(p);
					int percentage;
					if (this.plugin.damagemode) {
						health = (int) e.getDamage();
						percentage = 100 - health * 100 / maxhealth;
					} else {
						health -= (int) e.getDamage();
						percentage = health * 100 / maxhealth;
					}
					this.plugin.functions.sendBorder(p, percentage);
				}
			}
		}
	}

	@SuppressWarnings("unused")
	@EventHandler(ignoreCancelled = true)
	protected void onJoin(final PlayerJoinEvent e) {
		if (this.isEnabled() && !this.plugin.fade) {
			final Player p = e.getPlayer();
			if (this.plugin.functions.isTintEnabled(p)) {
				final int percentage = this.plugin.functions.getPlayerHealthPercentage(p);
				final Runnable run = new Runnable() {
					@Override
					public void run() {
						TintHealth_PlayerListener.this.plugin.functions.sendBorder(p, percentage);
					}
				};
				Bukkit.getScheduler().runTask((Plugin) this.plugin, (Runnable) new Runnable() {
					@Override
					public void run() {
						TintHealth_PlayerListener.this.plugin.functions.sendBorder(p, percentage);
					}
				});
			}
		}
	}

	@EventHandler(ignoreCancelled = true)
	protected void onTeleport(final PlayerTeleportEvent e) {
		if (this.isEnabled() && !this.plugin.fade) {
			final Player p = e.getPlayer();
			if (this.plugin.functions.isTintEnabled(p)
					&& this.plugin.functions.getPlayerHealth(p) <= this.plugin.minhearts) {
				final int percentage = this.plugin.functions.getPlayerHealthPercentage(p);
				Bukkit.getScheduler().runTask((Plugin) this.plugin, (Runnable) new Runnable() {
					@Override
					public void run() {
						TintHealth_PlayerListener.this.plugin.functions.sendBorder(p, percentage);
					}
				});
			}
		}
	}

	@EventHandler(ignoreCancelled = true)
	protected void onHeal(final EntityRegainHealthEvent e) {
		if (this.isEnabled() && !this.plugin.fade && e.getEntity() instanceof Player) {
			final Player p = (Player) e.getEntity();
			if (this.plugin.functions.isTintEnabled(p)) {
				final Damageable d = (Damageable) p;
				final double heal = e.getAmount();
				final int health = (int) (d.getHealth() + heal);
				this.plugin.functions.sendBorder(p, health);
			}
		}
	}
}
