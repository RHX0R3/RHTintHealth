package eu.raidersheaven.RHTintHealth.Forked;

import org.bukkit.entity.Player;

public class TintHealth_API {
	private static Main plugin;
	private static TintHealth_Functions functions;

	public static void setTint(final Player p, final int percentage) {
		TintHealth_API.functions.setBorder(p, 100 - percentage);
	}

	public static void fadeTint(final Player p, final int startpercentage, final int timeInSeconds) {
		TintHealth_API.functions.fadeBorder(p, 100 - startpercentage, timeInSeconds);
	}

	public static void removeTint(final Player p) {
		TintHealth_API.functions.removeBorder(p);
	}

	public static int getIntensityModifier() {
		return TintHealth_API.plugin.intensity;
	}

	public static boolean isFadeEnabled() {
		return TintHealth_API.plugin.fade;
	}

	public static int getFadeTime() {
		return TintHealth_API.plugin.fadetime;
	}

	public static void sendTint(final Player p, final int percentage) {
		TintHealth_API.functions.sendBorder(p, 100 - percentage);
	}

	public static boolean isTHEnabled() {
		return TintHealth_API.plugin.enabled;
	}

	public static void enable() {
		TintHealth_API.plugin.enabled = true;
	}

	public static void disable() {
		TintHealth_API.plugin.enabled = false;
	}

	static {
		TintHealth_API.plugin = Main.getInstance();
		TintHealth_API.functions = TintHealth_API.plugin.functions;
	}
}
